"""Fixed administrator inspection of an installed E0 control selection.

The trust origin is protected deployment plus the existing authenticated OS
administrator, not self-consistent JSON or a caller's path/hash/permission flag.
The public entry accepts only a study identity and uses fixed production paths.
Private helpers are test/composition seams inside that trusted process, not an
authorization API or a sandbox against a malicious administrator.

The public inspector reads selected CONTROL metadata only. The private future
executor composition additionally prepares only the selected prelabel method,
task manifest and original frozen membership. Neither path reads reservations,
source packets, labels, annotations or provider output; initializes, publishes,
repairs or activates a study; or infers genuine reviewer independence from a
metadata reference. Missing selection fails closed.
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys

from . import market_memory_contextual_registration as control
from .market_memory_e0_access_history import (
    MAX_ACCESS_HISTORY_BYTES, MAX_ACCESS_RECORDS, validate_access_history,
    validate_evaluation_access_history,
)

INSTALLED_ROOT = Path("/opt/macro")
CONTROL_ROOT = INSTALLED_ROOT / "data/research_factory/market_memory_e0"
SELECTED_SCHEMA = "research_factory.market_memory_e0_selected_control.v1"
_CONTROL_KEYS = {"registration": ("registration", "study_id"),
                 "closure": ("prelabel_closure", "closure_id"),
                 "publication": ("publication", "publication_id"),
                 "installation": ("installed_binding", "installation_id"),
                 "access": ("access_state", "access_state_id")}
_MODULE_PATH = "engine/research_factory/market_memory_e0_installed_control.py"
_SOURCE_PATHS = (
    "engine/__init__.py",
    "scripts/inspect_market_memory_e0_control.py",
    "engine/research_factory/__init__.py", "engine/research_factory/schema.py",
    "engine/research_factory/state.py", "engine/research_factory/ledger.py",
    "engine/research_factory/codegen_boundary.py",
    "engine/research_factory/market_memory_contextual_registration.py",
    "engine/research_factory/market_memory_e0_access_history.py",
    "engine/research_factory/market_memory_e0_reservations.py",
    _MODULE_PATH,
) + tuple(f"contracts/market_memory/e0_{kind}.v1.schema.json" for kind in control.KINDS)
_TASK_SOURCE_PATHS = _SOURCE_PATHS + (
    "engine/neuralweb/__init__.py", "engine/neuralweb/market_memory.py",
    "engine/neuralweb/market_memory_episode_comparison.py",
    "engine/neuralweb/market_memory_episode_features.py",
    "engine/neuralweb/market_memory_episode_retrieval.py",
    "engine/neuralweb/market_memory_operating_cortex_service.py",
    "engine/neuralweb/market_memory_pit.py", "engine/neuralweb/market_memory_projection.py",
    "engine/neuralweb/market_memory_retained_context_cohort.py",
    "engine/neuralweb/market_memory_trusted.py",
    "engine/research_factory/market_memory_e0_baselines.py",
    "engine/research_factory/market_memory_e0_condition_evidence.py",
    "engine/research_factory/market_memory_e0_task_evidence.py",
    "contracts/market_memory/e0_tasks.v1.schema.json",
)
_PREPARED_TOKEN = object()
_INPUT_NAMES = ("registration", "method_manifest", "task_manifest", "frozen_membership")


class E0InstalledControlError(ValueError):
    """Stable reason only. No paths, raw exception text or private bodies."""


def _require(ok: bool, reason: str) -> None:
    if not ok:
        raise E0InstalledControlError(reason)


def _identity(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns,
            info.st_mode, info.st_uid, info.st_nlink)


@contextmanager
def _directory(path: Path, *, private: bool):
    """Hold every nonsymlink ancestor and recheck names before releasing them."""
    _require(path.is_absolute() and all(p not in (".", "..") for p in path.parts),
             "absolute_metadata_path_required")
    chain = []
    try:
        current = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
        chain.append((current, None, None))
        for component in path.parts[1:]:
            child = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                            dir_fd=current)
            chain.append((child, current, component))
            current = child
        for descriptor, _parent, _name in chain:
            info = os.fstat(descriptor)
            _require(stat.S_ISDIR(info.st_mode) and info.st_uid in (0, os.geteuid())
                     and not stat.S_IMODE(info.st_mode) & 0o022, "unsafe_metadata_ancestor")
        if private:
            info = os.fstat(current)
            _require(info.st_uid == os.geteuid() and stat.S_IMODE(info.st_mode) == 0o700,
                     "private_metadata_directory_required")
        yield current
        for descriptor, parent, name in chain[1:]:
            named = os.stat(name, dir_fd=parent, follow_symlinks=False)
            held = os.fstat(descriptor)
            _require(held.st_uid in (0, os.geteuid()) and not stat.S_IMODE(held.st_mode) & 0o022,
                     "unsafe_metadata_ancestor")
            if private and descriptor == current:
                _require(held.st_uid == os.geteuid() and stat.S_IMODE(held.st_mode) == 0o700,
                         "private_metadata_directory_required")
            _require((held.st_dev, held.st_ino) == (named.st_dev, named.st_ino),
                     "metadata_directory_changed")
    except OSError as exc:
        raise E0InstalledControlError("metadata_directory_unavailable") from exc
    finally:
        for descriptor, _parent, _name in reversed(chain):
            os.close(descriptor)


def _read(descriptor: int, name: str, limit: int, *, private=True) -> bytes:
    _require("/" not in name and name not in ("", ".", ".."), "metadata_filename_invalid")
    opened = None
    try:
        opened = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC,
                         dir_fd=descriptor)
        before = os.fstat(opened)
        mode = stat.S_IMODE(before.st_mode)
        _require(stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid()
                 and before.st_nlink == 1 and (mode == 0o600 if private else not mode & 0o022),
                 "unsafe_metadata_file")
        _require((0 < before.st_size <= limit) if private else (0 <= before.st_size <= limit),
                 "metadata_file_byte_limit")
        body = bytearray()
        while len(body) <= limit:
            chunk = os.read(opened, min(65536, limit + 1 - len(body)))
            if not chunk:
                break
            body.extend(chunk)
        after = os.fstat(opened)
        named = os.stat(name, dir_fd=descriptor, follow_symlinks=False)
        _require(_identity(before) == _identity(after) == _identity(named)
                 and len(body) == before.st_size, "metadata_file_changed")
        return bytes(body)
    except OSError as exc:
        raise E0InstalledControlError("metadata_file_unavailable") from exc
    finally:
        if opened is not None:
            os.close(opened)


def _verify_source(root: Path, commit: str, *, paths=_SOURCE_PATHS) -> None:
    """Selected source identity must equal installed bytes; never fetch Git data."""
    _require(type(commit) is str and re.fullmatch(r"[a-f0-9]{40}", commit) is not None,
             "selected_source_commit_invalid")
    environment = {**{k: v for k, v in os.environ.items() if not k.startswith("GIT_")},
                   "GIT_NO_LAZY_FETCH": "1", "GIT_NO_REPLACE_OBJECTS": "1",
                   "GIT_OPTIONAL_LOCKS": "0", "GIT_TERMINAL_PROMPT": "0",
                   "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": os.devnull,
                   "GIT_ALLOW_PROTOCOL": ""}
    try:
        # ls-tree also accepts a raw tree OID. A matching tree is not the
        # selected commit identity promised by the installed-control contract.
        kind = subprocess.run(
            ["/usr/bin/git", "-C", str(root), "cat-file", "-t", commit],
            capture_output=True, timeout=10, check=True, env=environment)
        _require(kind.stdout == b"commit\n" and not kind.stderr,
                 "selected_source_commit_invalid")
        result = subprocess.run(
            ["/usr/bin/git", "-C", str(root), "ls-tree", "-rz", commit, "--", *paths],
            capture_output=True, timeout=10, check=True,
            env=environment)
    except (OSError, subprocess.SubprocessError) as exc:
        raise E0InstalledControlError("selected_source_unavailable") from exc
    _require(not result.stderr and len(result.stdout) <= 65536, "selected_source_listing_invalid")
    expected = {}
    try:
        for row in result.stdout.rstrip(b"\0").split(b"\0"):
            metadata, path = row.split(b"\t")
            mode, kind, digest = metadata.split()
            _require(kind == b"blob" and mode in (b"100644", b"100755"), "selected_source_type_invalid")
            expected[path.decode()] = digest.decode()
    except (ValueError, UnicodeError) as exc:
        raise E0InstalledControlError("selected_source_listing_invalid") from exc
    _require(set(expected) == set(paths), "selected_source_closure_incomplete")
    for relative, expected_digest in expected.items():
        path = root / relative
        with _directory(path.parent, private=False) as descriptor:
            body = _read(descriptor, path.name, 512 * 1024, private=False)
        digest = hashlib.sha1(f"blob {len(body)}\0".encode() + body).hexdigest()
        _require(digest == expected_digest, "installed_source_changed")


def _load_selected_control(directory: Path, study_id: str, verify_source, *, clock, prepare=None):
    """Unchanged legacy immutable-scope profile."""
    return _load_selected_control_records(directory,study_id,verify_source,
        clock=clock,prepare=prepare,_evaluation_history=False)


def _load_selected_evaluation_control(directory: Path, study_id: str, verify_source, *, clock, prepare=None):
    """Fixed NEW evaluation-scope profile; metadata checks are not authority.

    No request controls this selector or supplies scope objects. Protected FD
    reads below resolve every historical scope and its stable native purpose.
    """
    return _load_selected_control_records(directory,study_id,verify_source,
        clock=clock,prepare=prepare,_evaluation_history=True)


def _load_selected_evaluation_request(directory,study_id,raw_request,capability):
    """Fixed prospective issuer path; no caller-defined preparation/terminal hook.

    The private issuer binds directory/study/request itself. Authority comes
    from current native grant/control/peer, never a supplied successful result.
    """
    from . import market_memory_e0_evaluation_issuer as evaluation
    # The genuine peer must be current before opening any private metadata,
    # as well as during preparation and the terminal phase below.
    evaluation.case._peer_binding(capability)
    return _load_selected_control_records(directory,study_id,evaluation._verify_source,
        clock=evaluation._iso_clock,prepare=None,_evaluation_history=True,
        _evaluation_request=(raw_request,capability))


def _load_selected_control_records(directory,study_id,verify_source,*,clock,prepare,_evaluation_history,
        _evaluation_request=None):
    """Trusted internal composition. Public entry binds every argument itself."""
    _require(type(study_id) is str and control._ID.fullmatch(study_id) is not None,
             "study_identity_invalid")
    with _directory(directory, private=True) as descriptor:
        selected_bytes = _read(descriptor, "SELECTED.json", 16384)
        selected = control._domain_json(selected_bytes)
        _require(type(selected) is dict and set(selected) ==
                 {"schema", "study_id", "source_commit", "control_refs"}, "selected_control_shape_invalid")
        _require(control._snapshot(selected)[1] == selected_bytes
                 and selected["schema"] == SELECTED_SCHEMA and selected["study_id"] == study_id,
                 "selected_control_identity_invalid")
        refs = selected["control_refs"]
        _require(type(refs) is dict and set(refs) == set(_CONTROL_KEYS), "selected_control_refs_invalid")
        _require(verify_source(selected["source_commit"]) is None, "source_verifier_contract")
        cached = {}
        total = 0

        def load(ref, kind, identity):
            nonlocal total
            ref = control._domain_reference(ref)
            _require(ref["schema"] == control.SCHEMAS[kind]
                     and ref["bytes"] <= control.MAX_CONTROL_BYTES, "control_reference_kind_invalid")
            digest = ref["sha256"]
            if digest not in cached:
                body = _read(descriptor, digest + ".json", control.MAX_CONTROL_BYTES)
                total += len(body)
                _require(total <= MAX_ACCESS_HISTORY_BYTES, "selected_control_byte_limit")
                cached[digest] = body
            body = cached[digest]
            _require(len(body) == ref["bytes"] and hashlib.sha256(body).hexdigest() == digest,
                     "selected_control_bytes_mismatch")
            record = control.parse_e0_control_record(body, kind=kind)
            _require(record[identity] == ref["object_id"], "selected_control_object_mismatch")
            return record, body

        records = {key: load(refs[key], *definition)[0] for key, definition in _CONTROL_KEYS.items()}
        _require(records["registration"]["study_id"] == study_id, "selected_study_mismatch")
        now = clock()
        control.validate_e0_control_join(**records, as_of=now)
        reverse = []
        seen = set()
        ref = refs["access"]
        while ref is not None:
            _require(ref["sha256"] not in seen and len(reverse) < MAX_ACCESS_RECORDS,
                     "access_history_cycle_or_limit")
            seen.add(ref["sha256"])
            state, body = load(ref, "access_state", "access_state_id")
            reverse.append(body)
            ref = state["previous_state_ref"]
        # History qualifies BEFORE selected evidence preparation. The only
        # new profile is selected by the fixed internal native entry above.
        ordered_history=list(reversed(reverse))
        if _evaluation_history:
            # Acquire public schemas before any terminal private/currentness
            # boundary. Both history passes validate these same source bytes.
            schema_documents=[]
            for name in ('e0_evaluation_source.v1.schema.json','e0_native_bindings.v3.schema.json'):
                with _directory(Path(__file__).resolve().parents[2]/'contracts/market_memory',private=False) as schema_fd:
                    schema_documents.append(_read(schema_fd,name,128*1024,private=False))
            schema_documents=tuple(schema_documents)
            def reference_bytes(ref,expected_schema):
                nonlocal total
                ref=control._domain_reference(ref)
                _require(ref['schema']==expected_schema and ref['bytes']<=control.MAX_CONTROL_BYTES,
                         'evaluation_reference_kind')
                digest=ref['sha256']
                if digest not in cached:
                    body=_read(descriptor,digest+'.json',control.MAX_CONTROL_BYTES)
                    total+=len(body);_require(total<=MAX_ACCESS_HISTORY_BYTES,'selected_control_byte_limit')
                    cached[digest]=body
                body=cached[digest]
                _require(len(body)==ref['bytes'] and hashlib.sha256(body).hexdigest()==digest,
                         'evaluation_reference_bytes')
                value=control._domain_json(body)
                _require(control._domain_snapshot(value)[1]==body and value.get('schema')==ref['schema']
                    and value.get('object_id')==ref['object_id'],'evaluation_reference_identity')
                return body,value
            scope_objects={};first_scope=None
            for raw in ordered_history:
                state=control.parse_e0_control_record(raw,kind='access_state')
                body,scope=reference_bytes(state['scope_ref'],'research_factory.market_memory_e0_evaluation_scope.v1')
                scope_objects[state['scope_ref']['sha256']]=body
                if first_scope is None:first_scope=scope
            purpose_body,_=reference_bytes(first_scope['purpose_ref'],'research_factory.market_memory_e0_evaluation_purpose.v1')
            service_body,_=reference_bytes(records['installation']['admin_receipt_ref'],'research_factory.market_memory_e0_native_service.v3')
            validate_evaluation_access_history(installation=records['installation'],history=ordered_history,as_of=now,
                scope_objects=scope_objects,purpose_body=purpose_body,service_body=service_body,
                source_commit=selected['source_commit'],schema_documents=schema_documents)
        else:
            validate_access_history(installation=records['installation'],history=ordered_history,as_of=now)
        if _evaluation_request is not None:
            _require(_evaluation_history and prepare is None,'fixed_evaluation_request_entry')
            from . import market_memory_e0_evaluation_issuer as evaluation
            raw_request,capability=_evaluation_request
            prepared=evaluation._prepare_evaluation_request(descriptor,selected,records,
                cached[refs['registration']['sha256']],raw_request,capability,schema_documents)
        else:
            prepared = None if prepare is None else prepare(
                descriptor, selected, records, cached[refs["registration"]["sha256"]])
        _require(verify_source(selected["source_commit"]) is None, "source_verifier_contract")
        if _evaluation_request is not None:
            # FIXED terminal dispatch, after real blocking source verification.
            # No caller-provided callback or request-selectable verifier exists.
            prepared=evaluation._finish_evaluation_request(descriptor,prepared,capability)
        if prepare is not None or _evaluation_history:
            for digest, original in cached.items():
                _require(_read(descriptor, digest + ".json", control.MAX_CONTROL_BYTES) == original,
                         "selected_control_record_changed")
        _require(_read(descriptor, "SELECTED.json", 16384) == selected_bytes,
                 "selected_control_changed")
        final_now = clock()
        _require(control._clock(final_now) >= control._clock(now), "owner_clock_reversed")
        joined = control.validate_e0_control_join(**records, as_of=final_now)
        if _evaluation_history:
            checked=validate_evaluation_access_history(installation=records['installation'],history=ordered_history,as_of=final_now,
                scope_objects=scope_objects,purpose_body=purpose_body,service_body=service_body,
                source_commit=selected['source_commit'],schema_documents=schema_documents)
        else:
            checked=validate_access_history(installation=records['installation'],history=ordered_history,as_of=final_now)
        summary = {"schema": "research_factory.market_memory_e0_installed_control_inspection.v1",
                "authority": "display_only", "study_id": study_id,
                "source_commit": selected["source_commit"], "metadata_consistent": joined["metadata_consistent"],
                "access_history": checked, "domain_payloads_read": False,
                "reservation_store_read": False, "labels_read": False,
                "provider_invoked": False, "runtime_writes": False, "operational_admission": False}
        if _evaluation_history:
            summary.update(schema='research_factory.market_memory_e0_evaluation_control_inspection.v1',
                domain_payloads_read=True,evaluation_scope_metadata_read=True,
                current_selection_authenticated=False)
        return summary if prepare is None and _evaluation_request is None else (prepared, selected_bytes)


def inspect_selected_control(study_id: str) -> dict:
    """Read one fixed private selection as the deployed OS administrator."""
    _require(sys.platform == "linux" and os.geteuid() == 0
             and Path(__file__).resolve() == INSTALLED_ROOT / _MODULE_PATH,
             "installed_administrator_entry_required")
    _verify_loaded_sources()
    _require(type(study_id) is str and control._ID.fullmatch(study_id) is not None,
             "study_identity_invalid")
    directory = CONTROL_ROOT / hashlib.sha256(study_id.encode()).hexdigest()
    return _load_selected_control(directory, study_id,
                                  lambda commit: _verify_source(INSTALLED_ROOT, commit),
                                  clock=lambda: datetime.now(timezone.utc).isoformat(
                                      timespec="microseconds").replace("+00:00", "Z"))


def _verify_loaded_sources(*, paths=_SOURCE_PATHS) -> None:
    """Match executed project modules to the source files the owner verifies."""
    for relative in paths:
        if not relative.startswith("engine/") or not relative.endswith(".py"):
            continue
        name = relative.removesuffix(".py").replace("/", ".").removesuffix(".__init__")
        module = sys.modules.get(name)
        # The code-generation guard is in the source dependency closure but
        # is loaded lazily by unrelated Factory functions, not this inspector.
        if module is None and name == "engine.research_factory.codegen_boundary":
            continue
        origin = getattr(module, "__file__", None)
        _require(type(origin) is str and Path(origin).resolve() == INSTALLED_ROOT / relative,
                 "loaded_source_origin_invalid")


def _prepare_task_bytes(descriptor, selected, records, registration, *, task_id):
    """Only the three named prelabel roles; no general reference traversal."""
    from . import market_memory_e0_task_evidence as tasks
    access, installation, reg = records["access"], records["installation"], records["registration"]
    _require(access["status"] == "active" and access["contamination_state"] == "clean"
             and {"read_e0_registration", "disclose_e0_registration"}
             <= set(installation["permitted_actions"]), "current_prelabel_metadata_access_required")
    roles = (
        ("method_manifest", reg["implementation"]["method_ref"], tasks.METHOD_SCHEMA, tasks.MAX_METHOD_BYTES),
        ("task_manifest", reg["tasks_ref"], control._TASK_SCHEMA, control.MAX_DOMAIN_OBJECT_BYTES),
        ("frozen_membership", reg["corpus"]["membership_ref"],
         "market_memory.e0_original_owner_metadata_membership.v1", control.MAX_DOMAIN_OBJECT_BYTES),
    )
    # Qualify every role and aggregate declared size before opening any of them.
    for _name, ref, schema, limit in roles:
        control._domain_reference(ref)
        _require(ref["schema"] == schema and ref["bytes"] <= limit, "selected_prelabel_role_invalid")
    _require(len({ref["sha256"] for _, ref, _, _ in roles}) == len(roles),
             "selected_prelabel_role_alias")
    _require(reg["corpus"]["membership_ref"]["sha256"] == control._FROZEN_DOMAIN_DIGESTS["membership"],
             "selected_frozen_membership_mismatch")
    _require(sum(ref["bytes"] for _, ref, _, _ in roles) <= control.MAX_DOMAIN_TOTAL_BYTES,
             "selected_prelabel_byte_limit")
    values = {"registration": registration}
    for name, ref, _schema, limit in roles:
        body = _read(descriptor, ref["sha256"] + ".json", limit)
        _require(len(body) == ref["bytes"] and hashlib.sha256(body).hexdigest() == ref["sha256"],
                 "selected_prelabel_bytes_mismatch")
        values[name] = body
    tasks.resolve_registered_task_inputs(**values)
    manifest = control._domain_json(values["task_manifest"])
    _require(sum(task["task_id"] == task_id for task in manifest["tasks"]) == 1,
             "selected_registered_task_required")
    return tuple(values[name] for name in _INPUT_NAMES)


@dataclass(frozen=True, slots=True, init=False, repr=False)
class _SelectedTaskInputs:
    _study_id: str
    _task_id: str
    _selection: bytes
    _inputs: tuple
    _seal: object

    def __init__(self, study_id, task_id, selection, inputs, *, _key=None):
        _require(_key is _PREPARED_TOKEN, "selected_task_inputs_required")
        for name, value in (("_study_id", study_id), ("_task_id", task_id),
                            ("_selection", selection), ("_inputs", inputs), ("_seal", _key)):
            object.__setattr__(self, name, value)


def _prepare_selected_task_inputs(study_id: str, task_id: str):
    """Fixed installed-owner metadata preparation, never study/read admission.

    The future executor still owes full domain qualification, actual independent
    closure, current source-use authorization and a durable operation reservation
    before source packets, provider calls, annotations or labels. This function
    does not call a source reader, initialize storage or create a selection.
    """
    _require(sys.platform == "linux" and os.geteuid() == 0
             and Path(__file__).resolve() == INSTALLED_ROOT / _MODULE_PATH,
             "installed_administrator_entry_required")
    for value in (study_id, task_id):
        _require(type(value) is str and control._ID.fullmatch(value) is not None,
                 "study_or_task_identity_invalid")
    from . import market_memory_e0_task_evidence  # Load only the verified fixed composition.
    _verify_loaded_sources(paths=_TASK_SOURCE_PATHS)
    directory = CONTROL_ROOT / hashlib.sha256(study_id.encode()).hexdigest()
    values, selection = _load_selected_control(directory, study_id,
        lambda commit: _verify_source(INSTALLED_ROOT, commit, paths=_TASK_SOURCE_PATHS),
        clock=lambda: datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z"),
        prepare=lambda fd, selected, records, registration: _prepare_task_bytes(
            fd, selected, records, registration, task_id=task_id))
    return _SelectedTaskInputs(study_id, task_id, selection, values, _key=_PREPARED_TOKEN)


def _current_selected_task_bytes(prepared):
    """Re-read current selected metadata before an executor consumes the bytes."""
    _require(type(prepared) is _SelectedTaskInputs and prepared._seal is _PREPARED_TOKEN,
             "selected_task_inputs_required")
    current = _prepare_selected_task_inputs(prepared._study_id, prepared._task_id)
    _require(current._selection == prepared._selection and current._inputs == prepared._inputs,
             "prepared_selection_or_inputs_changed")
    return dict(zip(_INPUT_NAMES, current._inputs))
